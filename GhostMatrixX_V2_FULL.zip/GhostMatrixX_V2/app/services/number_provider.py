from dataclasses import dataclass
from datetime import datetime
@dataclass
class NumberResult:
    provider_id:str; phone:str; country:str; country_name:str; service:str; expires_at:datetime|None
class NumberProvider:
    async def buy(self,country,service,kind='temporary'): raise NotImplementedError
    async def release(self,provider_id): raise NotImplementedError
class DemoNumberProvider(NumberProvider):
    async def buy(self,country,service,kind='temporary'): return None
    async def release(self,provider_id): return True
provider=DemoNumberProvider()
