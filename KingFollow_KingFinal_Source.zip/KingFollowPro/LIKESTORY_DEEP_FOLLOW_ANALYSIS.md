# LikeStory 1.7.5 — deep follower-flow map used for King Follow

## 1. What is directly evidenced in the APK

The APK contains these backend routes/classes/fields:

- `/auth/register`, `/auth/login`, `/auth/refresh-token`, `/auth/confirm-account/{otpCode}`
- `/account/profile`, `/account/coins-reward`, `/account/list-posts-to-increase`, `/account/posts-statistics`, `/account/add-fcm-token`, `/account/update-last-presence`
- `/posts/add-post`, `/posts/create-post-transaction/{postId}`, `/posts/get-post/{postId}`, `/posts/list-posts`, `/posts/delete-post/{postId}`
- `ReactorService`, `ReactorPreProcessor`, `ReactorPostProcessor`, `TaskScheduler`
- `FacebookFollowWorker`, `FacebookReactionWorker`, `FacebookGroupJoinWorker`, `FacebookSessionWorker`
- `ReactionPost`, `Post`, `PostActivity`, `CoinsRewardResponse`
- `FOLLOW_ACCOUNT`, `FACEBOOK_FOLLOW`, `FollowAccount`
- `currentCount`, `maxCount`, `finishDate`, `activities`
- `coins`, `dailyRewards`, `nextRewardDate`
- `X-Wait-Time`

## 2. Reward flow

The app does not rely on a phone-only timer for the reward. It calls `/account/coins-reward`, receives a response containing `xWaitTime`, and the account model also exposes `nextRewardDate` and `dailyRewards`.

King Follow therefore uses the same architectural principle:

```text
Android timer = display only
Backend clock  = authority
Claim request  = authenticated + transactional
```

King Follow's requested rule is fixed at:

```text
100 points / 3600 seconds
```

A late user gets one successful hourly claim at a time; the server resets the next eligibility time. This avoids minting a large batch after changing the device clock.

## 3. The follower task pipeline seen in LikeStory

The important chain is:

```text
Server lists work
    ↓
/account/list-posts-to-increase
    ↓
ReactionPost records
    ↓
ReactorPreProcessor
    ↓
Map/queue + scheduled execution time
    ↓
TaskScheduler
    ↓
WorkManager OneTimeWorkRequest
    ↓
FacebookFollowWorker
    ↓
WebView opens target URL
    ↓
Facebook page UI is inspected
    ↓
Follow action is attempted
    ↓
Bridge reports OK / KO
    ↓
ReactorPostProcessor
    ↓
/posts/create-post-transaction/{postId}
    ↓
server records the transaction
```

This is materially different from simply increasing a counter in the APK.

## 4. Facebook follow worker details

The APK contains a dedicated `FacebookFollowWorker` with a WebView, cookies, JavaScript, DOM storage, a latch, a WebClient and result callback.

The worker:

1. Receives a `ReactionPost`.
2. Configures a WebView.
3. Enables cookies, JavaScript and DOM storage.
4. Selects a mobile/desktop browser mode as required.
5. Adds a JavaScript bridge named `Bridge`.
6. Converts the target link to a Facebook mobile URL.
7. Loads the target.
8. Evaluates JavaScript that searches for the localized Follow UI.
9. If the first selector is not found, it looks for an options menu and retries after a short delay.
10. The web page sends `Bridge.onFollowResult('OK')` or `Bridge.onFollowResult('KO')`.
11. The worker returns success/failure to the reactor layer.
12. The reactor processor records a server-side post transaction.

The APK also contains localized follow labels including English, Arabic and French. This matters for a global app because selector logic cannot assume English.

## 5. Queue semantics

`ReactorPreProcessor` turns each work item into a queued structure containing platform, link, objective/action and post ID, plus timing information.

Execution is handed to WorkManager with network constraints and an initial delay. This allows the Android process to survive longer than a single UI event.

For a production King Follow equivalent, the queue must additionally be idempotent:

```text
same order + same target + same worker
        ↓
 never create two successful delivery records
```

## 6. Post transaction semantics

The worker result is not the end of the process. The app sends a server request to create a post transaction. This is where the central system can update counters, prevent duplicate transactions, and associate delivery activity with a specific order/post.

Therefore King Follow keeps:

```text
service_order
provider_job
provider_job_events
verification_events
```

as separate records.

## 7. Why the uploaded APK is not simply a Facebook API client

The discovered Facebook follower worker is a WebView/browser automation component rather than a simple Graph API call. The APK also contains a Facebook session worker and encrypted local preference storage for its Facebook session object.

King Follow intentionally does NOT reproduce automated password entry, session-cookie extraction, or credential scraping. Account connection belongs in an OAuth/authorized-account flow, while follower delivery belongs in a separate server/provider layer.

## 8. X/Twitter finding

`Twitter` exists as a platform enum in the LikeStory APK, but a parallel `TwitterFollowWorker` was not found in the examined application classes. The clearly visible worker implementation is primarily Facebook/Instagram oriented.

King Follow therefore should not pretend that LikeStory 1.7.5 proves an identical X worker.

Current X API references expose a user-context follow operation at `POST /2/users/{id}/following`; the calling account must be authorized as the source user. citeturn404826search1turn404826search2

## 9. King Follow implementation decision

The resulting product architecture is:

```text
                KING FOLLOW APK
                       │
        ┌──────────────┼──────────────┐
        │              │              │
     Account         Wallet         Orders
        │              │              │
        └──────────────┴──────┬───────┘
                              ↓
                        KING FOLLOW API
                              ↓
                       Provider Job Queue
                              ↓
                  ┌───────────┴───────────┐
                  │                       │
             Facebook adapter         X adapter
                  │                       │
        authorized/provider flow   authorized user context
                  │                       │
                  └───────────┬───────────┘
                              ↓
                         Verification
                              ↓
                       Order progress
```

The user does not earn points by doing another user's task. The only free-point mechanism requested is the server-authoritative 100-point hourly reward.

## 10. What still requires a real delivery source

No APK can create external followers out of nothing. To move an order from `queued` to `completed`, King Follow needs a real delivery source:

- an authorized service/provider integration, or
- a separate, legitimate participant/operations system that is allowed to perform the action.

The current project already exposes `provider_jobs` and a webhook-style synchronization endpoint so that the delivery source can be attached server-side later without shipping its secret into the APK.
