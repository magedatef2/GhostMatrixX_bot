<?php
declare(strict_types=1);
require dirname(__DIR__).'/config.php';
require __DIR__.'/GenericProvider.php';

function db2(): PDO {
    return new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
}

$pdo = db2();
$provider = new GenericProvider(FOLLOW_PROVIDER_BASE_URL, FOLLOW_PROVIDER_API_KEY);
$pdo->beginTransaction();
try {
    $q = $pdo->query("SELECT pj.*, so.service_type FROM provider_jobs pj JOIN service_orders so ON so.id=pj.order_id WHERE pj.status='queued' AND pj.available_at<=NOW() ORDER BY pj.id LIMIT 1 FOR UPDATE");
    $job = $q->fetch();
    if (!$job) { $pdo->commit(); exit(0); }
    $pdo->prepare("UPDATE provider_jobs SET status='assigned',locked_at=NOW(),attempt_count=attempt_count+1 WHERE id=?")
        ->execute([(int)$job['id']]);
    $pdo->prepare("UPDATE service_orders SET status='processing' WHERE id=? AND status='pending'")
        ->execute([(int)$job['order_id']]);
    $pdo->commit();

    $created = $provider->create((string)$job['platform'], (string)$job['service_type'], (string)$job['target_url'], (int)$job['quantity']);
    $providerId = (string)($created['id'] ?? $created['order_id'] ?? '');
    if ($providerId === '') throw new RuntimeException('provider_missing_order_id');
    $pdo->prepare("UPDATE provider_jobs SET provider_job_id=?,status='running',source_account_ref=? WHERE id=?")
        ->execute([$providerId, (string)($created['source_account'] ?? 'provider'), (int)$job['id']]);
    $pdo->prepare("UPDATE service_orders SET provider=?,provider_order_id=?,status='processing' WHERE id=?")
        ->execute(['generic', $providerId, (int)$job['order_id']]);
    echo "Created provider order {$providerId} for job {$job['id']}\n";
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    fwrite(STDERR, "worker error: ".$e->getMessage()."\n");
    exit(1);
}
