package com.kingfollow.app.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.kingfollow.app.data.ApiClient
import com.kingfollow.app.data.SessionStore

class OrderSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (SessionStore.getToken().isNullOrBlank()) return Result.success()
        return runCatching { ApiClient.api.me(); ApiClient.api.orders(); Result.success() }.getOrElse { Result.retry() }
    }
}
