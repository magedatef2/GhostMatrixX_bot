#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1 || ! command -v gradle >/dev/null 2>&1; then
  echo "ثبت Java 17 وGradle أولاً: pkg update && pkg install openjdk-17 gradle unzip -y" >&2
  exit 1
fi
gradle --version >/dev/null
gradle assembleRelease
APK="app/build/outputs/apk/release/app-release.apk"
[ -f "$APK" ]
mkdir -p ../KingFollow-Release
cp "$APK" ../KingFollow-Release/KingFollow.apk
echo "BUILD OK: $PWD/$APK"
