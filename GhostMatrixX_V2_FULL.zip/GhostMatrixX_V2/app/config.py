import os
from dotenv import load_dotenv
load_dotenv()
BOT_TOKEN = os.getenv('BOT_TOKEN','').strip()
OWNER_ID = int(os.getenv('OWNER_ID','0') or 0)
DATABASE_URL = os.getenv('DATABASE_URL','sqlite:///ghostmatrixx.db')
APP_SECRET = os.getenv('APP_SECRET','change-me')
DEFAULT_PRICE = int(os.getenv('DEFAULT_PRICE','50'))
FREE_DURATION_DAYS = int(os.getenv('FREE_DURATION_DAYS','3'))
CURRENCY = os.getenv('CURRENCY','EGP')
