COUNTRIES = [
('🇪🇬','مصر','EG'),('🇺🇸','الولايات المتحدة','US'),('🇬🇧','المملكة المتحدة','GB'),('🇨🇦','كندا','CA'),
('🇩🇪','ألمانيا','DE'),('🇫🇷','فرنسا','FR'),('🇮🇹','إيطاليا','IT'),('🇪🇸','إسبانيا','ES'),
('🇳🇱','هولندا','NL'),('🇸🇪','السويد','SE'),('🇨🇭','سويسرا','CH'),('🇦🇪','الإمارات','AE'),
('🇸🇦','السعودية','SA'),('🇹🇷','تركيا','TR'),('🇮🇳','الهند','IN'),('🇯🇵','اليابان','JP'),
('🇦🇺','أستراليا','AU'),('🇧🇷','البرازيل','BR')]
SERVICES = [
('💬','WhatsApp','whatsapp'),('✈️','Telegram','telegram'),('📘','Facebook','facebook'),('📸','Instagram','instagram'),
('👻','Snapchat','snapchat'),('🎵','TikTok','tiktok'),('🟣','Viber','viber'),('𝕏','X / Twitter','x')]
PAYMENTS = [('🟠','Orange Cash','orange'),('🔴','Vodafone Cash','vodafone'),('🟣','e& money','etisalat'),('🔵','WE Pay','we')]
