# King Follow Release Checklist

## Required before APK release
- Deploy backend over HTTPS.
- Set `KINGFOLLOW_API_BASE_URL` in `local.properties` or Gradle property.
- Set database password only on the server.
- Configure email delivery (SMTP/API) for verification codes.
- Configure Facebook/X OAuth redirect URIs on the server.
- Configure a legitimate follower-service/provider if follower delivery is offered.
- Never put Facebook App Secret, X Client Secret, X Bearer Token, provider API key, DB password, or SMTP credentials in the APK.

## Build
`gradle clean assembleRelease -PKINGFOLLOW_API_BASE_URL=https://YOUR-PRODUCTION-DOMAIN.example/`

Output:
`app/build/outputs/apk/release/app-release.apk`

## Acceptance tests
1. Register.
2. Receive and confirm email code.
3. Login.
4. Confirm reward cannot be claimed early.
5. After the server makes it available, claim exactly 100 points.
6. Create a valid Facebook/X order.
7. Confirm points are deducted exactly once.
8. Confirm order survives app restart.
9. Confirm provider updates are idempotent.
10. Confirm cancellation/refund follows server policy.
11. Test airplane mode/network recovery.
12. Install the signed release APK on at least one real Android device.
