# النشر

Repository: `magedatef2/GhostMatrixX_bot`

ضع BOT_TOKEN وOWNER_ID في Environment/Secrets ولا تضعهما داخل GitHub.

Bot: `python -m app`
Dashboard: `uvicorn app.web:app --host 0.0.0.0 --port 8000`
