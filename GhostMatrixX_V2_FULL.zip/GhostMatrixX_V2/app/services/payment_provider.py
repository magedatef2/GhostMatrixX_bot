from dataclasses import dataclass
@dataclass
class PaymentResult:
    payment_id:str; checkout_url:str|None; status:str
class PaymentProvider:
    async def create_checkout(self,order_id,amount,method): raise NotImplementedError
    async def verify_webhook(self,payload,signature): raise NotImplementedError
class DemoPaymentProvider(PaymentProvider):
    async def create_checkout(self,order_id,amount,method): return PaymentResult(f'DEMO-{order_id}',None,'pending')
    async def verify_webhook(self,payload,signature): return False
payment_provider=DemoPaymentProvider()
