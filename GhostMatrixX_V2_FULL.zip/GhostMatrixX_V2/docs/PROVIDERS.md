# ربط المزودين

## مزود الأرقام
نفّذ `buy` و`release` في `app/services/number_provider.py` باستخدام API لمزود أرقام مصرح به.

## الدفع
نفّذ `create_checkout` و`verify_webhook` في `app/services/payment_provider.py`. يجب تأكيد الدفع من الخادم وليس من صور الإيصالات.

## التغطية
وجود المنصة في القائمة لا يضمن قبول الرقم؛ كل منصة ومزود لهما سياسات وتغطية مختلفة.
