SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS provider_job_events;
DROP TABLE IF EXISTS provider_jobs;
DROP TABLE IF EXISTS verification_events;
DROP TABLE IF EXISTS service_orders;
DROP TABLE IF EXISTS point_ledger;
DROP TABLE IF EXISTS social_accounts;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS email_verification_codes;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS app_settings;

CREATE TABLE users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 points BIGINT NOT NULL DEFAULT 0,
 next_reward_at DATETIME NOT NULL,
 email_verified_at DATETIME NULL,
 status ENUM('active','blocked','pending','suspended') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_reward(next_reward_at),
 INDEX idx_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE email_verification_codes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 code_hash CHAR(64) NOT NULL,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_verification_user(user_id,expires_at),
 INDEX idx_verification_active(user_id,consumed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sessions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_seen_at DATETIME NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_session_user(user_id), INDEX idx_session_exp(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE point_ledger (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 order_id BIGINT UNSIGNED NULL,
 amount BIGINT NOT NULL,
 balance_after BIGINT NOT NULL,
 reason VARCHAR(120) NOT NULL,
 idempotency_key VARCHAR(190) NULL UNIQUE,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_ledger_user(user_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE social_accounts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 platform ENUM('facebook','x') NOT NULL,
 platform_user_id VARCHAR(190) NULL,
 username VARCHAR(190) NULL,
 display_name VARCHAR(190) NULL,
 access_token_encrypted MEDIUMTEXT NULL,
 refresh_token_encrypted MEDIUMTEXT NULL,
 expires_at DATETIME NULL,
 scopes TEXT NULL,
 status ENUM('connected','expired','revoked','pending') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_user_platform(user_id,platform),
 UNIQUE KEY uq_platform_account(platform,platform_user_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE service_orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 platform ENUM('facebook','x') NOT NULL,
 service_type ENUM('followers','likes') NOT NULL,
 target_url VARCHAR(800) NOT NULL,
 target_platform_id VARCHAR(190) NULL,
 quantity INT UNSIGNED NOT NULL,
 start_count INT UNSIGNED NULL,
 delivered_count INT UNSIGNED NOT NULL DEFAULT 0,
 cost_points BIGINT NOT NULL,
 provider VARCHAR(80) NULL,
 provider_order_id VARCHAR(190) NULL,
 status ENUM('pending','processing','partial','completed','failed','cancelled','refunded') NOT NULL DEFAULT 'pending',
 last_provider_sync_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_orders_user(user_id,created_at), INDEX idx_orders_status(status),
 INDEX idx_provider(provider,provider_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE provider_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT UNSIGNED NOT NULL,
 platform ENUM('facebook','x') NOT NULL,
 action ENUM('follow','like') NOT NULL,
 target_url VARCHAR(800) NOT NULL,
 target_platform_id VARCHAR(190) NULL,
 quantity INT UNSIGNED NOT NULL,
 completed_count INT UNSIGNED NOT NULL DEFAULT 0,
 provider_job_id VARCHAR(190) NULL,
 source_account_ref VARCHAR(190) NULL,
 status ENUM('queued','assigned','running','submitted','verified','failed','cancelled') NOT NULL DEFAULT 'queued',
 attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
 available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 locked_at DATETIME NULL,
 completed_at DATETIME NULL,
 last_error VARCHAR(500) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(order_id) REFERENCES service_orders(id) ON DELETE CASCADE,
 INDEX idx_jobs_queue(status,available_at), INDEX idx_jobs_order(order_id),
 INDEX idx_jobs_provider(provider_job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE provider_job_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 event_type VARCHAR(60) NOT NULL,
 external_id VARCHAR(190) NULL,
 payload JSON NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(job_id) REFERENCES provider_jobs(id) ON DELETE CASCADE,
 INDEX idx_job_events(job_id,created_at),
 INDEX idx_job_events_external(external_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE verification_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT UNSIGNED NOT NULL,
 result ENUM('pending','passed','failed') NOT NULL DEFAULT 'pending',
 before_count INT UNSIGNED NULL,
 observed_count INT UNSIGNED NULL,
 details JSON NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(order_id) REFERENCES service_orders(id) ON DELETE CASCADE,
 INDEX idx_verification_order(order_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE app_settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value VARCHAR(500) NOT NULL,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_settings(setting_key,setting_value) VALUES
('reward_points','100'),
('reward_interval_seconds','3600'),
('registration_bonus','0'),
('facebook_enabled','1'),
('x_enabled','1'),
('youtube_enabled','0'),
('tiktok_enabled','0'),
('service_followers_enabled','1'),
('service_likes_enabled','1')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

SET FOREIGN_KEY_CHECKS=1;
