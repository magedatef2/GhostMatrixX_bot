from datetime import datetime, timezone
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from app.config import DATABASE_URL
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread':False} if DATABASE_URL.startswith('sqlite') else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'; id:Mapped[int]=mapped_column(primary_key=True); telegram_id:Mapped[int]=mapped_column(Integer,unique=True,index=True); username:Mapped[str]=mapped_column(String(255),default=''); balance:Mapped[int]=mapped_column(Integer,default=0); is_owner:Mapped[bool]=mapped_column(Boolean,default=False); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class Number(Base):
    __tablename__='numbers'; id:Mapped[int]=mapped_column(primary_key=True); provider_id:Mapped[str]=mapped_column(String(255),default=''); phone:Mapped[str]=mapped_column(String(64),default=''); country:Mapped[str]=mapped_column(String(8),default=''); country_name:Mapped[str]=mapped_column(String(100),default=''); service:Mapped[str]=mapped_column(String(50),default=''); kind:Mapped[str]=mapped_column(String(30),default='temporary'); status:Mapped[str]=mapped_column(String(30),default='available'); price:Mapped[int]=mapped_column(Integer,default=50); expires_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
class Order(Base):
    __tablename__='orders'; id:Mapped[int]=mapped_column(primary_key=True); telegram_id:Mapped[int]=mapped_column(Integer,index=True); number_id:Mapped[int|None]=mapped_column(ForeignKey('numbers.id'),nullable=True); country:Mapped[str]=mapped_column(String(8),default=''); service:Mapped[str]=mapped_column(String(50),default=''); duration:Mapped[str]=mapped_column(String(30),default='3'); amount:Mapped[int]=mapped_column(Integer,default=0); status:Mapped[str]=mapped_column(String(30),default='pending'); payment_method:Mapped[str]=mapped_column(String(50),default=''); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class Payment(Base):
    __tablename__='payments'; id:Mapped[int]=mapped_column(primary_key=True); order_id:Mapped[int]=mapped_column(ForeignKey('orders.id')); provider:Mapped[str]=mapped_column(String(50),default=''); transaction_id:Mapped[str]=mapped_column(String(255),default=''); amount:Mapped[int]=mapped_column(Integer,default=0); status:Mapped[str]=mapped_column(String(30),default='pending'); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class AdminLog(Base):
    __tablename__='admin_logs'; id:Mapped[int]=mapped_column(primary_key=True); owner_id:Mapped[int]=mapped_column(Integer); action:Mapped[str]=mapped_column(Text); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
def init_db(): Base.metadata.create_all(engine)
