# 👻 GhostMatrixX_bot — V2

نسخة V2 منظمة لبوت Telegram بواجهة عربية Dark/Neon، قاعدة بيانات، نظام طلبات، أنواع أرقام مجانية/دائمة، وضع مالك، ولوحة تحكم ويب.

## نموذج الخدمة
- 🎁 مجاني: 3 أيام.
- 💎 دائم: 50 EGP، بدون انتهاء تلقائي من جانب النظام، مع بقاء الرقم خاضعًا لمزود الرقم وشروطه.
- 👑 Owner: المالك يستطيع طلب أرقام مجانية لنفسه.
- الدفع مصمم للربط مع Orange Cash / Vodafone Cash / e& money / WE Pay عبر مزود دفع رسمي أو API موثوق.

## مهم
المشروع لا ينفذ اعتراض OTP أو إعادة توجيه أكواد التحقق أو تجاوز حماية أي منصة. ربط الأرقام يتم فقط عبر مزود أرقام مصرح به، وأي قبول للرقم على WhatsApp/Telegram/Facebook/Instagram/Snapchat/TikTok/Viber/X يعتمد على المنصة والمزود.

## تشغيل سريع
1. أنشئ Bot Token جديدًا من BotFather؛ التوكن الذي تم نشره سابقًا يجب إلغاؤه.
2. انسخ `.env.example` إلى `.env`.
3. ضع BOT_TOKEN و OWNER_ID.
4. `pip install -r requirements.txt`
5. `python -m app`
6. لوحة التحكم: `uvicorn app.web:app --host 0.0.0.0 --port 8000`
