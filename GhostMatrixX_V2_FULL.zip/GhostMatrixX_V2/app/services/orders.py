from datetime import datetime,timedelta,timezone
from app.db import SessionLocal,User,Order,Number
from app.config import OWNER_ID,DEFAULT_PRICE,FREE_DURATION_DAYS
from app.services.number_provider import provider
def ensure_user(telegram_id,username=''):
    with SessionLocal() as db:
        u=db.query(User).filter(User.telegram_id==telegram_id).first()
        if not u:
            u=User(telegram_id=telegram_id,username=username or '',is_owner=telegram_id==OWNER_ID); db.add(u); db.commit(); db.refresh(u)
        return u
async def create_paid_order(telegram_id,country,service,duration,payment_method):
    with SessionLocal() as db:
        o=Order(telegram_id=telegram_id,country=country,service=service,duration=duration,amount=DEFAULT_PRICE,status='awaiting_payment',payment_method=payment_method); db.add(o); db.commit(); db.refresh(o); return o.id
async def claim_free_for_owner(telegram_id,country,service):
    if telegram_id!=OWNER_ID:return None
    result=await provider.buy(country,service,'owner_free')
    if not result:return None
    with SessionLocal() as db:
        n=Number(provider_id=result.provider_id,phone=result.phone,country=result.country,country_name=result.country_name,service=result.service,kind='owner_free',status='active',price=0,expires_at=datetime.now(timezone.utc)+timedelta(days=FREE_DURATION_DAYS)); db.add(n); db.commit(); db.refresh(n); return n
