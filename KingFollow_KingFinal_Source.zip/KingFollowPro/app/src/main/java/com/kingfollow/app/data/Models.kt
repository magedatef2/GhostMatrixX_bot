package com.kingfollow.app.data

data class User(
    val id: Long,
    val email: String,
    val points: Long,
    val status: String,
    val next_reward_at: String?
)

data class AuthResponse(
    val ok: Boolean,
    val token: String? = null,
    val user: User? = null,
    val error: String? = null,
    val status: String? = null,
    val requires_verification: Boolean? = null
)

data class RewardResponse(
    val ok: Boolean,
    val credited: Long = 0,
    val points: Long = 0,
    val available_at: String? = null,
    val seconds_remaining: Long = 0,
    val error: String? = null
)

data class MeResponse(
    val ok: Boolean,
    val user: User? = null,
    val reward: RewardResponse? = null,
    val error: String? = null
)

data class ServiceItem(
    val platform: String,
    val type: String,
    val unit: String,
    val cost_points: Long,
    val enabled: Boolean
)

data class ServicesResponse(val ok: Boolean, val services: List<ServiceItem> = emptyList())

data class CreateOrderResponse(
    val ok: Boolean,
    val order: Order? = null,
    val remaining_points: Long? = null,
    val error: String? = null,
    val required: Long? = null,
    val points: Long? = null
)

data class Order(
    val id: Long,
    val platform: String,
    val service_type: String,
    val target_url: String,
    val quantity: Int,
    val start_count: Int? = null,
    val delivered_count: Int = 0,
    val cost_points: Long,
    val status: String,
    val provider: String? = null,
    val provider_order_id: String? = null,
    val created_at: String? = null,
    val updated_at: String? = null
)

data class OrdersResponse(val ok: Boolean, val orders: List<Order> = emptyList(), val error: String? = null)

data class SocialAccount(
    val platform: String,
    val platform_user_id: String? = null,
    val username: String? = null,
    val display_name: String? = null,
    val expires_at: String? = null,
    val scopes: String? = null,
    val status: String
)

data class SocialAccountsResponse(val ok: Boolean, val accounts: List<SocialAccount> = emptyList())

data class BasicResponse(val ok: Boolean, val error: String? = null, val refunded: Long? = null)
