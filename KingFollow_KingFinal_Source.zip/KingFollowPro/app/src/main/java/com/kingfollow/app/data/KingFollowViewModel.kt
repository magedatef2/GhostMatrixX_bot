package com.kingfollow.app.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.Duration

data class UiState(
    val loading: Boolean = false,
    val authenticated: Boolean = false,
    val user: User? = null,
    val services: List<ServiceItem> = emptyList(),
    val orders: List<Order> = emptyList(),
    val accounts: List<SocialAccount> = emptyList(),
    val rewardSeconds: Long = 0,
    val message: String? = null
)

class KingFollowViewModel : ViewModel() {
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            val me = runCatching { ApiClient.api.me() }.getOrNull()
            if (me?.isSuccessful == true && me.body()?.ok == true) {
                SessionStore.setToken(SessionStore.getToken())
                loadAll()
            } else if (!SessionStore.getToken().isNullOrBlank()) {
                SessionStore.clear()
            }
            startTimer()
        }
    }

    fun login(email: String, password: String) = viewModelScope.launch {
        setLoading(true)
        val r = runCatching { ApiClient.api.login(mapOf("email" to email.trim(), "password" to password)) }.getOrNull()
        val body = r?.body()
        if (r?.isSuccessful == true && body?.ok == true && !body.token.isNullOrBlank()) {
            SessionStore.setToken(body.token)
            loadAll()
            message(null)
        } else message(errorText(body?.error ?: "تعذر تسجيل الدخول"))
        setLoading(false)
    }

    fun register(email: String, password: String) = viewModelScope.launch {
        setLoading(true)
        val r = runCatching { ApiClient.api.register(mapOf("email" to email.trim(), "password" to password)) }.getOrNull()
        val body = r?.body()
        if (r?.isSuccessful == true && body?.ok == true) {
            if (!body.token.isNullOrBlank()) {
                SessionStore.setToken(body.token)
                loadAll()
            } else {
                message("تم إنشاء الحساب. أدخل رمز التحقق المرسل إلى بريدك الإلكتروني.")
            }
        } else message(errorText(body?.error ?: "تعذر إنشاء الحساب"))
        setLoading(false)
    }

    fun confirmAccount(email: String, code: String) = viewModelScope.launch {
        setLoading(true)
        val r = runCatching { ApiClient.api.confirmAccount(mapOf("email" to email.trim(), "code" to code.trim())) }.getOrNull()
        val body = r?.body()
        if (r?.isSuccessful == true && body?.ok == true && !body.token.isNullOrBlank()) {
            SessionStore.setToken(body.token)
            loadAll()
        } else message(errorText(body?.error ?: "رمز التحقق غير صحيح أو منتهي"))
        setLoading(false)
    }

    fun claimReward() = viewModelScope.launch {
        val r = runCatching { ApiClient.api.claimReward() }.getOrNull()
        val b = r?.body()
        if (r?.isSuccessful == true && b?.ok == true) {
            refreshMe()
            message(if (b.credited > 0) "تمت إضافة ${b.credited} نقطة" else "المكافأة لم تصبح متاحة بعد")
        } else message(errorText(b?.error ?: "تعذر استلام المكافأة"))
    }

    fun createFollowersOrder(platform: String, url: String, quantity: Int) = viewModelScope.launch {
        setLoading(true)
        val body = mapOf<String, Any>("platform" to platform, "service_type" to "followers", "target_url" to url.trim(), "quantity" to quantity)
        val r = runCatching { ApiClient.api.createOrder(body) }.getOrNull()
        val b = r?.body()
        if (r?.isSuccessful == true && b?.ok == true) {
            message("تم إنشاء الطلب #${b.order?.id ?: ""}")
            loadAll()
        } else message(errorText(b?.error ?: "تعذر إنشاء الطلب"))
        setLoading(false)
    }

    fun cancelOrder(id: Long) = viewModelScope.launch {
        val r = runCatching { ApiClient.api.cancelOrder(id) }.getOrNull()
        message(if (r?.isSuccessful == true && r.body()?.ok == true) "تم إلغاء الطلب وإرجاع النقاط المستحقة" else "لا يمكن إلغاء هذا الطلب")
        loadAll()
    }

    fun logout() = viewModelScope.launch {
        runCatching { ApiClient.api.logout() }
        SessionStore.clear()
        timerJob?.cancel()
        _state.value = UiState()
    }

    fun loadAll() = viewModelScope.launch {
        refreshMe()
        val services = runCatching { ApiClient.api.services().body()?.services ?: emptyList() }.getOrDefault(emptyList())
        val orders = runCatching { ApiClient.api.orders().body()?.orders ?: emptyList() }.getOrDefault(emptyList())
        val accounts = runCatching { ApiClient.api.socialAccounts().body()?.accounts ?: emptyList() }.getOrDefault(emptyList())
        _state.value = _state.value.copy(authenticated = true, services = services, orders = orders, accounts = accounts)
    }

    private suspend fun refreshMe() {
        val r = runCatching { ApiClient.api.me() }.getOrNull()
        val b = r?.body()
        if (r?.isSuccessful == true && b?.ok == true && b.user != null) {
            _state.value = _state.value.copy(authenticated = true, user = b.user, rewardSeconds = b.reward?.seconds_remaining ?: secondsUntil(b.user.next_reward_at))
        } else if (r?.code() == 401) {
            SessionStore.clear(); _state.value = UiState()
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                val remaining = _state.value.user?.next_reward_at?.let(::secondsUntil) ?: 0L
                _state.value = _state.value.copy(rewardSeconds = remaining)
                delay(1000)
            }
        }
    }

    private fun secondsUntil(iso: String?): Long {
        if (iso.isNullOrBlank()) return 0
        return runCatching { maxOf(0, Duration.between(Instant.now(), Instant.parse(iso)).seconds) }.getOrDefault(0)
    }

    private fun setLoading(v: Boolean) { _state.value = _state.value.copy(loading = v) }
    private fun message(v: String?) { _state.value = _state.value.copy(message = v) }
    fun clearMessage() { message(null) }
    private fun errorText(error: String): String = when (error) {
        "invalid_credentials" -> "البريد أو كلمة المرور غير صحيحة"
        "insufficient_points" -> "الرصيد غير كافٍ"
        "unsupported_target_domain" -> "الرابط ليس تابعاً للمنصة المختارة"
        "order_rate_limited" -> "تم الوصول إلى حد الطلبات مؤقتاً"
        "account_not_active" -> "الحساب غير مفعّل"
        else -> error
    }
}
