from telegram import InlineKeyboardButton,InlineKeyboardMarkup
from telegram.ext import Application,CommandHandler,CallbackQueryHandler
from app.config import BOT_TOKEN,OWNER_ID,DEFAULT_PRICE,FREE_DURATION_DAYS,CURRENCY
from app.data import COUNTRIES,SERVICES,PAYMENTS
from app.db import init_db,SessionLocal,User,Order,Number
from app.services.orders import ensure_user,create_paid_order,claim_free_for_owner

def own(uid): return bool(OWNER_ID and uid==OWNER_ID)
def menu(uid):
    rows=[[InlineKeyboardButton('🌍 شراء رقم',callback_data='countries')],[InlineKeyboardButton('🎁 رقم مجاني 3 أيام',callback_data='free')],[InlineKeyboardButton('📦 طلباتي',callback_data='orders'),InlineKeyboardButton('💰 محفظتي',callback_data='wallet')],[InlineKeyboardButton('📱 المنصات',callback_data='services'),InlineKeyboardButton('🌎 الدول',callback_data='countries')],[InlineKeyboardButton('❓ الدعم',callback_data='support'),InlineKeyboardButton('ℹ️ معلومات',callback_data='info')]]
    if own(uid):rows.append([InlineKeyboardButton('👑 لوحة المالك',callback_data='owner')])
    return InlineKeyboardMarkup(rows)
def back():return InlineKeyboardMarkup([[InlineKeyboardButton('⬅️ الرئيسية',callback_data='home')]])
async def start(update,context):
    u=update.effective_user;ensure_user(u.id,u.username)
    await update.message.reply_text('👻 <b>GhostMatrixX</b>\n━━━━━━━━━━━━\n🌐 متجر الأرقام الذكي\n\n🎁 مجاني: 3 أيام\n💎 دائم: 50 EGP\n👑 وضع المالك متاح للمالك فقط.',parse_mode='HTML',reply_markup=menu(u.id))
async def countries(q):
    rows=[]
    for i in range(0,len(COUNTRIES),2):rows.append([InlineKeyboardButton(f'{f} {n}',callback_data=f'country:{c}') for f,n,c in COUNTRIES[i:i+2]])
    rows.append([InlineKeyboardButton('⬅️ الرئيسية',callback_data='home')]);await q.edit_message_text('🌍 <b>اختر الدولة</b>',parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
async def country(q,c):
    n=next((n for _,n,x in COUNTRIES if x==c),c);rows=[[InlineKeyboardButton(f'{i} {s}',callback_data=f'buy:{c}:{k}') for i,s,k in SERVICES[i:i+2]] for i in range(0,len(SERVICES),2)];rows.append([InlineKeyboardButton('⬅️ الدول',callback_data='countries')]);await q.edit_message_text(f'🌍 <b>{n}</b>\n\nاختر المنصة:',parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
async def buy(q,c,s):
    name=next((n for _,n,k in SERVICES if k==s),s);kb=[[InlineKeyboardButton('🎁 مجاني — 3 أيام',callback_data=f'freebuy:{c}:{s}')],[InlineKeyboardButton('💎 دائم — 50 جنيه',callback_data=f'checkout:{c}:{s}:permanent')],[InlineKeyboardButton('⬅️ رجوع',callback_data=f'country:{c}')]];await q.edit_message_text(f'📱 <b>{name}</b>\n\n🎁 مجاني: 3 أيام\n💎 دائم: {DEFAULT_PRICE} {CURRENCY}',parse_mode='HTML',reply_markup=InlineKeyboardMarkup(kb))
async def pay(q,c,s,d):
    rows=[[InlineKeyboardButton(f'{f} {n}',callback_data=f'pay:{c}:{s}:{d}:{k}')] for f,n,k in PAYMENTS];rows.append([InlineKeyboardButton('⬅️ رجوع',callback_data=f'buy:{c}:{s}')]);await q.edit_message_text(f'💳 <b>الدفع</b>\n\nالمبلغ: {DEFAULT_PRICE} {CURRENCY}\n\nاختر المحفظة:',parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
async def cb(update,context):
    q=update.callback_query;await q.answer();uid=q.from_user.id;d=q.data
    if d=='home':await q.edit_message_text('👻 <b>GhostMatrixX</b>\n\nاختر الخدمة:',parse_mode='HTML',reply_markup=menu(uid))
    elif d=='countries':await countries(q)
    elif d.startswith('country:'):await country(q,d.split(':')[1])
    elif d.startswith('buy:'):
        _,c,s=d.split(':');await buy(q,c,s)
    elif d.startswith('checkout:'):
        _,c,s,dur=d.split(':');await pay(q,c,s,dur)
    elif d.startswith('pay:'):
        _,c,s,dur,m=d.split(':');oid=await create_paid_order(uid,c,s,dur,m);await q.edit_message_text(f'🧾 <b>الطلب #{oid}</b>\n\n💰 {DEFAULT_PRICE} {CURRENCY}\n💳 {m}\n\nجاهز لربط بوابة دفع رسمية والتحقق الآلي.',parse_mode='HTML',reply_markup=back())
    elif d.startswith('freebuy:'):
        _,c,s=d.split(':');await q.edit_message_text('🎁 <b>الرقم المجاني</b>\n\nالمدة 3 أيام.\n\nبعد ربط مزود أرقام مصرح به سيتم الحجز الفعلي.',parse_mode='HTML',reply_markup=back())
    elif d=='free':
        kb=[[InlineKeyboardButton('👑 رقم مجاني لي',callback_data='free_owner')]] if own(uid) else [];kb.append([InlineKeyboardButton('⬅️ الرئيسية',callback_data='home')]);await q.edit_message_text('🎁 <b>الأرقام المجانية</b>\n\nمدة الرقم: 3 أيام.\nالتوفر حسب المخزون.',parse_mode='HTML',reply_markup=InlineKeyboardMarkup(kb))
    elif d=='free_owner':
        rows=[[InlineKeyboardButton(f'{f} {n}',callback_data=f'owner_country:{c}') for f,n,c in COUNTRIES[i:i+2]] for i in range(0,len(COUNTRIES),2)];await q.edit_message_text('👑 اختر الدولة:',reply_markup=InlineKeyboardMarkup(rows))
    elif d.startswith('owner_country:'):
        c=d.split(':')[1];rows=[[InlineKeyboardButton(f'{i} {s}',callback_data=f'owner_buy:{c}:{k}') for i,s,k in SERVICES[i:i+2]] for i in range(0,len(SERVICES),2)];await q.edit_message_text('👑 اختر المنصة:',reply_markup=InlineKeyboardMarkup(rows))
    elif d.startswith('owner_buy:'):
        _,c,s=d.split(':');r=await claim_free_for_owner(uid,c,s);await q.edit_message_text(f'👑 {r.phone}' if r else '👑 مزود الأرقام Demo غير مربوط حاليًا. أضف API المزود المصرح به أولًا.',reply_markup=back())
    elif d=='services':await q.edit_message_text('📱 <b>المنصات</b>\n\n'+'\n'.join(f'{i} {s}' for i,s,_ in SERVICES),parse_mode='HTML',reply_markup=back())
    elif d=='orders':
        with SessionLocal() as db:xs=db.query(Order).filter(Order.telegram_id==uid).order_by(Order.id.desc()).limit(10).all()
        await q.edit_message_text('📦 <b>طلباتي</b>\n\n'+('\n'.join(f'#{x.id} — {x.amount} EGP — {x.status}' for x in xs) if xs else 'لا توجد طلبات.'),parse_mode='HTML',reply_markup=back())
    elif d=='wallet':
        with SessionLocal() as db:u=db.query(User).filter(User.telegram_id==uid).first();bal=u.balance if u else 0
        await q.edit_message_text(f'💰 <b>محفظتي</b>\n\nالرصيد: {bal} {CURRENCY}',parse_mode='HTML',reply_markup=back())
    elif d=='support':await q.edit_message_text('❓ <b>الدعم</b>\n\nسيتم ربط نظام التذاكر في النسخة المتقدمة.',parse_mode='HTML',reply_markup=back())
    elif d=='info':await q.edit_message_text('ℹ️ GhostMatrixX V2\n\nإدارة أرقام عبر مزود مصرح به. لا يوجد اعتراض OTP أو تجاوز حماية المنصات.',reply_markup=back())
    elif d=='owner':
        if not own(uid):return await q.edit_message_text('⛔ غير مصرح.',reply_markup=back())
        with SessionLocal() as db:users=db.query(User).count();orders=db.query(Order).count();nums=db.query(Number).count()
        await q.edit_message_text(f'👑 <b>لوحة المالك</b>\n\n👥 {users}\n📦 {orders}\n📱 {nums}',parse_mode='HTML',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('🎁 رقم مجاني لي',callback_data='free_owner')],[InlineKeyboardButton('⬅️ الرئيسية',callback_data='home')]]))
def run_bot():
    if not BOT_TOKEN:raise SystemExit('ضع BOT_TOKEN في .env')
    init_db();app=Application.builder().token(BOT_TOKEN).build();app.add_handler(CommandHandler('start',start));app.add_handler(CallbackQueryHandler(cb));app.run_polling()
