<?php
declare(strict_types=1);

// Production secrets belong on the server. Never put them in the APK or Git.
const DB_HOST = 'sql105.iceiy.com';
const DB_NAME = 'icei_42641533_Kingfollow';
const DB_USER = 'icei_42641533';
const DB_PASS = 'PUT_DB_PASSWORD_HERE';

const APP_NAME = 'King Follow';
const REWARD_POINTS = 100;
const REWARD_INTERVAL_SECONDS = 3600;
const SESSION_DAYS = 30;
const REGISTRATION_BONUS = 0;
const REQUIRE_EMAIL_VERIFICATION = true;
const APP_BASE_URL = 'https://YOUR-DOMAIN.example/api.php';
const SUPPORT_EMAIL = 'magedatef243@gmail.com';
const MAIL_FROM = 'no-reply@YOUR-DOMAIN.example';
const VERIFICATION_CODE_TTL_SECONDS = 900;

// Optional server-side provider configuration. Keep secrets in environment variables.
const FOLLOW_PROVIDER_BASE_URL = '';
const FOLLOW_PROVIDER_API_KEY = '';

// Server-side OAuth configuration placeholders. Populate only on the server.
const FACEBOOK_APP_ID = '';
const FACEBOOK_APP_SECRET = '';
const FACEBOOK_REDIRECT_URI = '';
const X_CLIENT_ID = '';
const X_CLIENT_SECRET = '';
const X_REDIRECT_URI = '';
const X_BEARER_TOKEN = '';

const MAX_ORDER_QTY = 1000000;
const MAX_ORDERS_PER_HOUR = 20;
