<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function out(array $data, int $code=200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function body(): array {
    $raw = file_get_contents('php://input') ?: '';
    $json = json_decode($raw, true);
    return is_array($json) ? $json : $_POST;
}
function bearer(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    return preg_match('/^Bearer\s+(.+)$/i', trim($h), $m) ? trim($m[1]) : null;
}
function authUser(bool $allowPending=false): array {
    $token = bearer();
    if (!$token || !preg_match('/^[a-f0-9]{64}$/', $token)) out(['ok'=>false,'error'=>'unauthorized'],401);
    $q = db()->prepare("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>NOW() LIMIT 1");
    $q->execute([hash('sha256',$token)]);
    $u = $q->fetch();
    if (!$u || in_array($u['status'], ['blocked','suspended'], true) || (!$allowPending && $u['status']!=='active')) {
        out(['ok'=>false,'error'=>'unauthorized'],401);
    }
    db()->prepare("UPDATE sessions SET last_seen_at=NOW() WHERE token_hash=?")->execute([hash('sha256',$token)]);
    return $u;
}
function addLedger(PDO $pdo,int $userId,int $amount,string $reason,?int $orderId=null,?string $key=null): void {
    $q=$pdo->prepare("SELECT points FROM users WHERE id=? FOR UPDATE");
    $q->execute([$userId]); $u=$q->fetch();
    if (!$u) throw new RuntimeException('user_not_found');
    $balance=(int)$u['points']+$amount;
    if ($balance<0) throw new RuntimeException('negative_balance');
    if ($key) {
        $exists=$pdo->prepare("SELECT id FROM point_ledger WHERE idempotency_key=? LIMIT 1");
        $exists->execute([$key]); if ($exists->fetch()) return;
    }
    $pdo->prepare("UPDATE users SET points=? WHERE id=?")->execute([$balance,$userId]);
    $pdo->prepare("INSERT INTO point_ledger(user_id,order_id,amount,balance_after,reason,idempotency_key) VALUES(?,?,?,?,?,?)")
        ->execute([$userId,$orderId,$amount,$balance,$reason,$key]);
}
function reward(PDO $pdo,int $userId): array {
    $q=$pdo->prepare("SELECT points,next_reward_at FROM users WHERE id=? FOR UPDATE");
    $q->execute([$userId]); $u=$q->fetch(); if(!$u) throw new RuntimeException('user_not_found');
    $now=time(); $next=strtotime((string)$u['next_reward_at']);
    if ($now < $next) return ['credited'=>0,'points'=>(int)$u['points'],'available_at'=>date('c',$next),'seconds_remaining'=>$next-$now];
    $key='hourly-reward:'.$userId.':'.$next;
    addLedger($pdo,$userId,REWARD_POINTS,'hourly free points',null,$key);
    $newNext=max($next,$now)+REWARD_INTERVAL_SECONDS;
    $pdo->prepare("UPDATE users SET next_reward_at=FROM_UNIXTIME(?) WHERE id=?")->execute([$newNext,$userId]);
    $p=$pdo->prepare("SELECT points FROM users WHERE id=?");$p->execute([$userId]);$points=(int)$p->fetchColumn();
    return ['credited'=>REWARD_POINTS,'points'=>$points,'available_at'=>date('c',$newNext),'seconds_remaining'=>$newNext-time()];
}
function validateTarget(string $platform,string $url): void {
    if (!filter_var($url,FILTER_VALIDATE_URL)) out(['ok'=>false,'error'=>'invalid_target_url'],422);
    $host=strtolower((string)parse_url($url,PHP_URL_HOST));
    $allowed=$platform==='facebook' ? ['facebook.com','www.facebook.com','m.facebook.com','mbasic.facebook.com'] : ['x.com','www.x.com','twitter.com','www.twitter.com'];
    $ok=false; foreach($allowed as $domain){ if($host===$domain || str_ends_with($host,'.'.$domain)){ $ok=true; break; } }
    if(!$ok) out(['ok'=>false,'error'=>'unsupported_target_domain'],422);
}
function orderRateLimit(PDO $pdo,int $userId): void {
    $q=$pdo->prepare("SELECT COUNT(*) FROM service_orders WHERE user_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)");
    $q->execute([$userId]); if((int)$q->fetchColumn()>=MAX_ORDERS_PER_HOUR) out(['ok'=>false,'error'=>'order_rate_limited'],429);
}

function sendVerificationCode(string $email,string $code): bool {
    $subject='King Follow — Email verification';
    $message="Your King Follow verification code is: {$code}\n\nThis code expires in 15 minutes.";
    $headers="From: ".MAIL_FROM."\r\n".
             "Reply-To: ".SUPPORT_EMAIL."\r\n".
             "Content-Type: text/plain; charset=UTF-8\r\n";
    return @mail($email,$subject,$message,$headers);
}
function issueVerification(PDO $pdo,int $userId,string $email): bool {
    $code=(string)random_int(100000,999999);
    $pdo->prepare("UPDATE email_verification_codes SET consumed_at=NOW() WHERE user_id=? AND consumed_at IS NULL")->execute([$userId]);
    $pdo->prepare("INSERT INTO email_verification_codes(user_id,code_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL ? SECOND))")
        ->execute([$userId,hash('sha256',$code),VERIFICATION_CODE_TTL_SECONDS]);
    return sendVerificationCode($email,$code);
}

$action=$_GET['action'] ?? '';

if($action==='health') out(['ok'=>true,'app'=>APP_NAME,'reward_points'=>REWARD_POINTS,'reward_interval_seconds'=>REWARD_INTERVAL_SECONDS,'facebook'=>true,'x'=>true]);

if($action==='register') {
    $b=body(); $email=strtolower(trim((string)($b['email']??''))); $password=(string)($b['password']??'');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<8) out(['ok'=>false,'error'=>'invalid_input'],422);
    $pdo=db(); $pdo->beginTransaction();
    try {
        $status=REQUIRE_EMAIL_VERIFICATION?'pending':'active';
        $next=time()+REWARD_INTERVAL_SECONDS;
        $q=$pdo->prepare("INSERT INTO users(email,password_hash,points,next_reward_at,email_verified_at,status) VALUES(?,?,?,?,?,?)");
        $q->execute([$email,password_hash($password,PASSWORD_DEFAULT),REGISTRATION_BONUS,date('Y-m-d H:i:s',$next),REQUIRE_EMAIL_VERIFICATION?null:date('Y-m-d H:i:s'),$status]);
        $uid=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO point_ledger(user_id,amount,balance_after,reason,idempotency_key) VALUES(?,?,?,?,?)")
            ->execute([$uid,REGISTRATION_BONUS,REGISTRATION_BONUS,'registration bonus','registration:'.$uid]);
        if(REQUIRE_EMAIL_VERIFICATION) {
            $sent=issueVerification($pdo,$uid,$email);
            $token=null;
        } else {
            $sent=true; $token=bin2hex(random_bytes(32));
            $pdo->prepare("INSERT INTO sessions(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL ? DAY))")
                ->execute([$uid,hash('sha256',$token),SESSION_DAYS]);
        }
        $pdo->commit();
        out(['ok'=>true,'token'=>$token,'requires_verification'=>REQUIRE_EMAIL_VERIFICATION,'verification_sent'=>$sent,'user'=>['id'=>$uid,'email'=>$email,'points'=>REGISTRATION_BONUS,'status'=>$status,'next_reward_at'=>date('c',$next)]]);
    } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>$e->getCode()==='23000'?'email_exists':'server_error'],500);}
}

if($action==='confirm_account') {
    $b=body(); $email=strtolower(trim((string)($b['email']??''))); $code=preg_replace('/\D+/','',(string)($b['code']??''));
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($code)!==6)out(['ok'=>false,'error'=>'invalid_code'],422);
    $pdo=db();$pdo->beginTransaction();
    try{
        $q=$pdo->prepare("SELECT u.*,c.id AS code_id,c.code_hash,c.expires_at FROM users u JOIN email_verification_codes c ON c.user_id=u.id WHERE u.email=? AND u.status='pending' AND c.consumed_at IS NULL ORDER BY c.id DESC LIMIT 1 FOR UPDATE");$q->execute([$email]);$row=$q->fetch();
        if(!$row || strtotime((string)$row['expires_at'])<time() || !hash_equals((string)$row['code_hash'],hash('sha256',$code))){$pdo->rollBack();out(['ok'=>false,'error'=>'invalid_or_expired_code'],422);}
        $now=date('Y-m-d H:i:s');
        $pdo->prepare("UPDATE email_verification_codes SET consumed_at=? WHERE id=?")->execute([$now,(int)$row['code_id']]);
        $pdo->prepare("UPDATE users SET status='active',email_verified_at=? WHERE id=?")->execute([$now,(int)$row['id']]);
        $token=bin2hex(random_bytes(32));
        $pdo->prepare("INSERT INTO sessions(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL ? DAY))")->execute([(int)$row['id'],hash('sha256',$token),SESSION_DAYS]);
        $pdo->commit();
        out(['ok'=>true,'token'=>$token,'user'=>['id'=>(int)$row['id'],'email'=>$row['email'],'points'=>(int)$row['points'],'status'=>'active','next_reward_at'=>date('c',strtotime($row['next_reward_at']))]]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
}

if($action==='resend_confirmation') {
    $b=body();$email=strtolower(trim((string)($b['email']??'')));if(!filter_var($email,FILTER_VALIDATE_EMAIL))out(['ok'=>false,'error'=>'invalid_input'],422);
    $pdo=db();$q=$pdo->prepare("SELECT id,email,status FROM users WHERE email=? LIMIT 1");$q->execute([$email]);$u=$q->fetch();
    if(!$u)out(['ok'=>true,'message'=>'If the account exists, a verification email has been sent.']);
    if($u['status']!=='pending')out(['ok'=>false,'error'=>'account_not_pending'],409);
    $sent=issueVerification($pdo,(int)$u['id'],$email);out(['ok'=>true,'verification_sent'=>$sent]);
}

if($action==='login') {
    $b=body();$email=strtolower(trim((string)($b['email']??'')));$password=(string)($b['password']??'');
    $q=db()->prepare("SELECT * FROM users WHERE email=? LIMIT 1");$q->execute([$email]);$u=$q->fetch();
    if(!$u||!password_verify($password,$u['password_hash'])) out(['ok'=>false,'error'=>'invalid_credentials'],401);
    if($u['status']!=='active') out(['ok'=>false,'error'=>'account_not_active','status'=>$u['status']],403);
    $token=bin2hex(random_bytes(32));
    db()->prepare("INSERT INTO sessions(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL ? DAY))")->execute([(int)$u['id'],hash('sha256',$token),SESSION_DAYS]);
    out(['ok'=>true,'token'=>$token,'user'=>['id'=>(int)$u['id'],'email'=>$u['email'],'points'=>(int)$u['points'],'next_reward_at'=>date('c',strtotime($u['next_reward_at']))]]);
}

if($action==='me') {
    $u=authUser();$pdo=db();$pdo->beginTransaction();try{$r=reward($pdo,(int)$u['id']);$pdo->commit();}catch(Throwable $e){$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
    $q=$pdo->prepare("SELECT id,email,points,status,next_reward_at FROM users WHERE id=?");$q->execute([(int)$u['id']]);$v=$q->fetch();
    out(['ok'=>true,'user'=>['id'=>(int)$v['id'],'email'=>$v['email'],'points'=>(int)$v['points'],'status'=>$v['status'],'next_reward_at'=>date('c',strtotime($v['next_reward_at']))],'reward'=>$r]);
}

if($action==='claim_reward') {
    $u=authUser();$pdo=db();$pdo->beginTransaction();try{$r=reward($pdo,(int)$u['id']);$pdo->commit();out(['ok'=>true]+$r);}catch(Throwable $e){$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
}

if($action==='services') {
    out(['ok'=>true,'services'=>[
        ['platform'=>'facebook','type'=>'followers','unit'=>'100','cost_points'=>100,'enabled'=>true],
        ['platform'=>'facebook','type'=>'likes','unit'=>'100','cost_points'=>60,'enabled'=>true],
        ['platform'=>'x','type'=>'followers','unit'=>'100','cost_points'=>120,'enabled'=>true],
        ['platform'=>'x','type'=>'likes','unit'=>'100','cost_points'=>80,'enabled'=>true],
    ]]);
}

if($action==='create_order') {
    $u=authUser();$b=body();orderRateLimit(db(),(int)$u['id']);
    $platform=(string)($b['platform']??'');$type=(string)($b['service_type']??'followers');$url=trim((string)($b['target_url']??''));$qty=(int)($b['quantity']??0);
    if(!in_array($platform,['facebook','x'],true)||!in_array($type,['followers','likes'],true)||$qty<1||$qty>MAX_ORDER_QTY)out(['ok'=>false,'error'=>'invalid_order'],422);
    validateTarget($platform,$url);
    $costPer100=$platform==='facebook'?($type==='followers'?100:60):($type==='followers'?120:80);
    $cost=(int)ceil($qty/100)*$costPer100;
    $pdo=db();$pdo->beginTransaction();
    try{
        $q=$pdo->prepare("SELECT points FROM users WHERE id=? FOR UPDATE");$q->execute([(int)$u['id']]);$wallet=(int)$q->fetchColumn();
        if($wallet<$cost){$pdo->rollBack();out(['ok'=>false,'error'=>'insufficient_points','required'=>$cost,'points'=>$wallet],409);}
        addLedger($pdo,(int)$u['id'],-$cost,'order purchase',null,'order:pending:'.bin2hex(random_bytes(8)));
        $q=$pdo->prepare("INSERT INTO service_orders(user_id,platform,service_type,target_url,quantity,cost_points,status) VALUES(?,?,?,?,?,?, 'pending')");
        $q->execute([(int)$u['id'],$platform,$type,$url,$qty,$cost]);$oid=(int)$pdo->lastInsertId();
        $action2=$type==='followers'?'follow':'like';
        $q=$pdo->prepare("INSERT INTO provider_jobs(order_id,platform,action,target_url,quantity,status) VALUES(?,?,?,?,?,'queued')");
        $q->execute([$oid,$platform,$action2,$url,$qty]);
        $pdo->commit();
        out(['ok'=>true,'order'=>['id'=>$oid,'platform'=>$platform,'service_type'=>$type,'quantity'=>$qty,'cost_points'=>$cost,'status'=>'pending'],'remaining_points'=>$wallet-$cost]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
}

if($action==='orders') {
    $u=authUser();$q=db()->prepare("SELECT id,platform,service_type,target_url,quantity,delivered_count,cost_points,status,created_at,updated_at FROM service_orders WHERE user_id=? ORDER BY id DESC LIMIT 100");$q->execute([(int)$u['id']]);
    $rows=$q->fetchAll();out(['ok'=>true,'orders'=>$rows]);
}

if($action==='order') {
    $u=authUser();$id=(int)($_GET['id']??0);$q=db()->prepare("SELECT id,platform,service_type,target_url,quantity,start_count,delivered_count,cost_points,status,provider,provider_order_id,created_at,updated_at FROM service_orders WHERE id=? AND user_id=? LIMIT 1");$q->execute([$id,(int)$u['id']]);$o=$q->fetch();if(!$o)out(['ok'=>false,'error'=>'order_not_found'],404);out(['ok'=>true,'order'=>$o]);
}

if($action==='cancel_order') {
    $u=authUser();$id=(int)($_GET['id']??0);$pdo=db();$pdo->beginTransaction();
    try{$q=$pdo->prepare("SELECT * FROM service_orders WHERE id=? AND user_id=? FOR UPDATE");$q->execute([$id,(int)$u['id']]);$o=$q->fetch();if(!$o)out(['ok'=>false,'error'=>'order_not_found'],404);if(!in_array($o['status'],['pending','processing'],true))out(['ok'=>false,'error'=>'cannot_cancel'],409);
        $pdo->prepare("UPDATE service_orders SET status='cancelled' WHERE id=?")->execute([$id]);
        $pdo->prepare("UPDATE provider_jobs SET status='cancelled' WHERE order_id=? AND status IN ('queued','assigned','running')")->execute([$id]);
        $balanceQ=$pdo->prepare("SELECT points FROM users WHERE id=? FOR UPDATE");$balanceQ->execute([(int)$u['id']]);$before=(int)$balanceQ->fetchColumn();$ref=(int)max(0,$o['cost_points']-0);
        if($ref>0){$pdo->prepare("UPDATE users SET points=points+? WHERE id=?")->execute([$ref,(int)$u['id']]);$new=$before+$ref;$pdo->prepare("INSERT INTO point_ledger(user_id,order_id,amount,balance_after,reason,idempotency_key) VALUES(?,?,?,?,?,?)")->execute([(int)$u['id'],$id,$ref,$new,'order cancellation refund','refund:'.$id]);}
        $pdo->commit();out(['ok'=>true,'refunded'=>$ref]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
}

if($action==='social_accounts') {
    $u=authUser();$q=db()->prepare("SELECT platform,platform_user_id,username,display_name,expires_at,scopes,status,updated_at FROM social_accounts WHERE user_id=? ORDER BY platform");$q->execute([(int)$u['id']]);out(['ok'=>true,'accounts'=>$q->fetchAll()]);
}

if($action==='logout') {
    $token=bearer();if($token)db()->prepare("DELETE FROM sessions WHERE token_hash=?")->execute([hash('sha256',$token)]);out(['ok'=>true]);
}

// This webhook is for a legitimate service/provider integration configured on the server.
// It intentionally does not accept social-media passwords or session cookies.
if($action==='provider_webhook') {
    $secret=$_SERVER['HTTP_X_PROVIDER_SECRET']??''; if(!$secret||!hash_equals(hash('sha256',(string)FOLLOW_PROVIDER_API_KEY),hash('sha256',(string)$secret)))out(['ok'=>false,'error'=>'forbidden'],403);
    $b=body();$providerId=trim((string)($b['provider_order_id']??''));$status=(string)($b['status']??'');$delivered=(int)($b['delivered_count']??0);
    if($providerId===''||!in_array($status,['pending','processing','partial','completed','failed'],true))out(['ok'=>false,'error'=>'invalid_webhook'],422);
    $pdo=db();$pdo->beginTransaction();try{$q=$pdo->prepare("SELECT pj.*,so.user_id FROM provider_jobs pj JOIN service_orders so ON so.id=pj.order_id WHERE pj.provider_job_id=? FOR UPDATE");$q->execute([$providerId]);$j=$q->fetch();if(!$j)out(['ok'=>false,'error'=>'job_not_found'],404);
        $pdo->prepare("UPDATE provider_jobs SET status=?,completed_count=?,updated_at=NOW() WHERE id=?")->execute([$status==='completed'?'verified':($status==='failed'?'failed':'running'),min($delivered,(int)$j['quantity']),(int)$j['id']]);
        $pdo->prepare("UPDATE service_orders SET delivered_count=?,status=?,last_provider_sync_at=NOW() WHERE id=?")->execute([min($delivered,(int)$j['quantity']),$status,(int)$j['order_id']]);
        $pdo->prepare("INSERT INTO provider_job_events(job_id,event_type,external_id,payload) VALUES(?,?,?,?)")->execute([(int)$j['id'],'provider_update',$providerId,json_encode($b,JSON_UNESCAPED_UNICODE)]);
        $pdo->commit();out(['ok'=>true]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>'server_error'],500);}
}

out(['ok'=>false,'error'=>'unknown_action'],404);
