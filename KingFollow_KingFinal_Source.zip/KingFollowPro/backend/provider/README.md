# King Follow Delivery Provider Interface

`provider_jobs` هو مكان ربط مصدر التسليم الحقيقي، وليس نظام تبادل نقاط للمستخدمين.

## دورة التنفيذ

```text
provider_jobs.status = queued
        ↓
adapter.create(job)
        ↓
provider_order_id
        ↓
processing / partial
        ↓
adapter.status(provider_order_id)
        ↓
delivered_count
        ↓
verification_events
        ↓
service_orders.status = completed
```

## قاعدة مهمة
لا يخزن هذا المشروع كلمات مرور Facebook أو X، ولا يستخرج session cookies من WebView.

لـ X، أي تنفيذ متابعة برمجي يجب أن يستخدم سياق مستخدم مصرحاً به؛ مرجع API الحالي يوضح عملية `POST /2/users/{id}/following` لإنشاء Follow. لذلك لا يكفي App-Only Bearer Token لإنشاء متابعة نيابة عن حساب شخص آخر.

لـ Facebook، لا نفترض وجود endpoint رسمي عام لمتابعة أي ملف شخصي. لذلك يجب ربط مزود أو مسار OAuth/صلاحيات مدعوم فعلياً بدلاً من اختلاق endpoint.
