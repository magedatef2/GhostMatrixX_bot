<?php
declare(strict_types=1);

final class GenericProvider {
    private string $base;
    private string $key;
    public function __construct(string $base, string $key) {
        $this->base = rtrim($base, '/');
        $this->key = $key;
    }
    private function request(string $method, string $path, ?array $payload=null): array {
        if ($this->base === '' || $this->key === '') {
            throw new RuntimeException('provider_not_configured');
        }
        $ch = curl_init($this->base.'/'.ltrim($path, '/'));
        if ($ch === false) throw new RuntimeException('curl_init_failed');
        $headers = ['Authorization: Bearer '.$this->key, 'Accept: application/json', 'Content-Type: application/json'];
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_TIMEOUT=>30, CURLOPT_HTTPHEADER=>$headers, CURLOPT_CUSTOMREQUEST=>$method]);
        if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($raw === false || $err !== '') throw new RuntimeException('provider_network_error');
        $data = json_decode((string)$raw, true);
        if (!is_array($data)) throw new RuntimeException('provider_invalid_json');
        if ($code < 200 || $code >= 300) throw new RuntimeException('provider_http_'.$code);
        return $data;
    }
    public function create(string $platform, string $service, string $target, int $quantity): array {
        return $this->request('POST', 'orders', compact('platform','service','target','quantity'));
    }
    public function status(string $providerOrderId): array {
        return $this->request('GET', 'orders/'.rawurlencode($providerOrderId));
    }
}
