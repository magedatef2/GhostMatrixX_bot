# King Follow — Deep Android build

King Follow هو تطبيق Android أصلي مستوحى من البنية التي ظهرت في LikeStory 1.7.5 الذي تم فحصه، مع نطاق Facebook + X فقط.

## المطلوب في هذا الإصدار
- 100 نقطة مجانية كل 60 دقيقة.
- الخادم هو مصدر الحقيقة للمكافأة؛ عداد التطبيق للعرض فقط.
- تسجيل حساب، تسجيل دخول، وتأكيد البريد الإلكتروني.
- Followers وLikes لكل من Facebook وX في كتالوج الخدمات.
- إنشاء الطلب مع خصم ذري من الرصيد.
- Order progress: pending → processing → partial/completed/failed.
- Provider Job Queue منفصل عن حساب المستخدم.
- Provider webhook لتحديث التقدم بطريقة idempotent.
- إلغاء الطلب واسترداد النقاط في الحالات المسموحة.
- حسابات اجتماعية منفصلة وتخزين الأسرار على الخادم فقط.
- WorkManager لمزامنة حالة الطلبات.
- لا يوجد YouTube أو TikTok.
- لا يوجد نظام يجعل المستخدمين يكسبون النقاط من تنفيذ طلبات مستخدمين آخرين.

## ما تم تأكيده من LikeStory APK
الـAPK يحتوي على `/account/coins-reward`, `/account/list-posts-to-increase`, `/posts/create-post-transaction/{postId}`، وطبقات `ReactorService`, `ReactorPreProcessor`, `TaskScheduler`, `FacebookFollowWorker`, `FacebookSessionWorker`، بالإضافة إلى `nextRewardDate`, `dailyRewards`, `currentCount`, `maxCount` و`X-Wait-Time`.

هذا يثبت أن النسخة المرجعية تستخدم خادماً مركزياً للمكافأة والطلبات، ثم طبقة جدولة/تنفيذ للمهام قبل تسجيل transaction. تفاصيل التنفيذ موثقة في `LIKESTORY_DEEP_FOLLOW_ANALYSIS.md`.

## حد مهم في التنفيذ
الـAPK المرجعي يحتوي على أتمتة WebView لإدخال بيانات Facebook وحفظ جلسات، لكن King Follow لا ينسخ إدخال كلمات المرور أو استخراج session cookies. الاتصال يجب أن يكون عبر OAuth/صلاحيات رسمية أو مزود تسليم مصرح به.

أيضاً: لا توجد طريقة تجعل APK ينشئ متابعين من العدم. لكي ينتقل Order إلى `completed` يجب وجود مصدر تسليم فعلي ومشروع، ويتم ربطه بالخادم في `backend/provider/`.

## الإعداد
1. استورد `backend/KINGFOLLOW_FINAL_DATABASE.sql`.
2. ضع كلمة مرور قاعدة البيانات الحقيقية داخل إعدادات الخادم فقط.
3. استخدم HTTPS لرابط API.
4. ضع أسرار Facebook/X/Provider في الخادم أو متغيرات بيئة؛ لا تضعها داخل APK.
5. إذا كان هناك مزود تسليم، اضبط `FOLLOW_PROVIDER_BASE_URL` و`FOLLOW_PROVIDER_API_KEY` ثم شغّل `backend/provider/worker.php` عبر Queue/Cron.

## البناء
من Android Studio: افتح المشروع وابنِ `assembleRelease`.

من Termux بعد تثبيت Java 17 وGradle وAndroid SDK/Build Tools:

```bash
./build-termux.sh
```

الناتج:

`app/build/outputs/apk/release/app-release.apk`

## الحالة الحالية
تم فحص PHP syntax وSQL structure محلياً. لم يتم الادعاء بوجود APK مبني داخل هذه البيئة لأن Android SDK/Build Tools غير مثبتة هنا.
