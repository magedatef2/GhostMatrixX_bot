package com.kingfollow.app.data

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @POST("api.php?action=register") suspend fun register(@Body body: Map<String, String>): Response<AuthResponse>
    @POST("api.php?action=login") suspend fun login(@Body body: Map<String, String>): Response<AuthResponse>
    @POST("api.php?action=confirm_account") suspend fun confirmAccount(@Body body: Map<String, String>): Response<AuthResponse>
    @POST("api.php?action=resend_confirmation") suspend fun resendConfirmation(@Body body: Map<String, String>): Response<BasicResponse>
    @GET("api.php?action=me") suspend fun me(): Response<MeResponse>
    @POST("api.php?action=claim_reward") suspend fun claimReward(): Response<RewardResponse>
    @GET("api.php?action=services") suspend fun services(): Response<ServicesResponse>
    @POST("api.php?action=create_order") suspend fun createOrder(@Body body: Map<String, Any>): Response<CreateOrderResponse>
    @GET("api.php?action=orders") suspend fun orders(): Response<OrdersResponse>
    @GET("api.php?action=order") suspend fun order(@Query("id") id: Long): Response<Map<String, Any>>
    @GET("api.php?action=social_accounts") suspend fun socialAccounts(): Response<SocialAccountsResponse>
    @POST("api.php?action=logout") suspend fun logout(): Response<BasicResponse>
    @POST("api.php?action=cancel_order") suspend fun cancelOrder(@Query("id") id: Long): Response<BasicResponse>
}
