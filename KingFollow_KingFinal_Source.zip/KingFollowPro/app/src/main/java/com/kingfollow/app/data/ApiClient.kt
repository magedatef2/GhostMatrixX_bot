package com.kingfollow.app.data

import android.content.Context
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object SessionStore {
    private const val PREFS = "king_follow_session"
    private const val TOKEN = "access_token"
    private var prefs: android.content.SharedPreferences? = null

    fun init(context: Context) { prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    fun setToken(value: String?) {
        if (value == null) prefs?.edit()?.remove(TOKEN)?.apply() else prefs?.edit()?.putString(TOKEN, value)?.apply()
    }
    fun getToken(): String? = prefs?.getString(TOKEN, null)
    fun clear() { prefs?.edit()?.remove(TOKEN)?.apply() }
}

private class AuthHeaderInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request()
        val token = SessionStore.getToken()
        val out = if (token.isNullOrBlank()) req else req.newBuilder().addHeader("Authorization", "Bearer $token").build()
        return chain.proceed(out)
    }
}

object ApiClient {
    private const val BASE_URL = BuildConfig.API_BASE_URL
    val api: ApiService by lazy {
        val http = OkHttpClient.Builder()
            .addInterceptor(AuthHeaderInterceptor())
            .build()
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(http)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
