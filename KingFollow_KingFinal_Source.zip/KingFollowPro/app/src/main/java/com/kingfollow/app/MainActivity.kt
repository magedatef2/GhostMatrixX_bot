package com.kingfollow.app

import android.os.Bundle
import java.util.concurrent.TimeUnit
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kingfollow.app.data.*
import java.util.Locale

private enum class Screen { HOME, SERVICES, ORDERS, PROFILE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionStore.init(applicationContext)
        val request = PeriodicWorkRequestBuilder<com.kingfollow.app.work.OrderSyncWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "king_follow_order_sync",
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            request
        )
        setContent { KingFollowApp() }
    }
}

@Composable
fun KingFollowApp(vm: KingFollowViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    MaterialTheme(colorScheme = darkColorScheme()) {
        if (!state.authenticated) {
            AuthScreen(state.loading, state.message, vm::login, vm::register, vm::confirmAccount, vm::clearMessage)
        } else {
            MainShell(state, vm)
        }
    }
}

@Composable
private fun AuthScreen(
    loading: Boolean,
    message: String?,
    login: (String,String)->Unit,
    register: (String,String)->Unit,
    confirm: (String,String)->Unit,
    clearMessage: ()->Unit
) {
    var registerMode by remember { mutableStateOf(false) }
    var verifyMode by remember { mutableStateOf(false) }
    var verifyCode by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("King Follow", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text(when { verifyMode -> "تأكيد البريد الإلكتروني"; registerMode -> "إنشاء حساب"; else -> "تسجيل الدخول" }, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(22.dp))
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("البريد الإلكتروني") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        if (verifyMode) {
            OutlinedTextField(verifyCode, { verifyCode = it.filter(Char::isDigit).take(6) }, Modifier.fillMaxWidth(), label = { Text("رمز التحقق") }, singleLine = true)
        } else {
            OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور — 8 أحرف على الأقل") }, singleLine = true)
        }
        Spacer(Modifier.height(18.dp))
        Button(
            enabled = !loading && email.isNotBlank() && (if (verifyMode) verifyCode.length == 6 else password.length >= 8),
            onClick = { if (verifyMode) confirm(email, verifyCode) else if (registerMode) register(email, password) else login(email, password) },
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
        ) { if (loading) CircularProgressIndicator(Modifier.size(20.dp)) else Text(if (verifyMode) "تأكيد الحساب" else if (registerMode) "إنشاء الحساب" else "دخول") }
        TextButton(onClick = { registerMode = !registerMode; verifyMode = false; clearMessage() }) {
            Text(if (registerMode) "لديك حساب بالفعل؟ تسجيل الدخول" else "ليس لديك حساب؟ إنشاء حساب")
        }
        if (!verifyMode && registerMode) {
            TextButton(onClick = { verifyMode = true; clearMessage() }) { Text("لديك رمز تحقق؟ تأكيد البريد") }
        }
        if (!message.isNullOrBlank()) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text(message, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
    }
}

@Composable
private fun MainShell(state: UiState, vm: KingFollowViewModel) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("King Follow", fontWeight = FontWeight.Bold) },
                actions = { Text("${state.user?.points ?: 0} نقطة", Modifier.padding(end = 14.dp), fontWeight = FontWeight.Bold) }
            )
        },
        bottomBar = {
            NavigationBar {
                NavItem(Icons.Default.Home, "الرئيسية", screen == Screen.HOME) { screen = Screen.HOME }
                NavItem(Icons.Default.ShoppingCart, "الخدمات", screen == Screen.SERVICES) { screen = Screen.SERVICES }
                NavItem(Icons.Default.List, "الطلبات", screen == Screen.ORDERS) { screen = Screen.ORDERS }
                NavItem(Icons.Default.Person, "حسابي", screen == Screen.PROFILE) { screen = Screen.PROFILE }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.HOME -> HomeScreen(state, vm)
                Screen.SERVICES -> ServicesScreen(state, vm)
                Screen.ORDERS -> OrdersScreen(state.orders, vm)
                Screen.PROFILE -> ProfileScreen(state, vm)
            }
        }
        if (!state.message.isNullOrBlank()) {
            LaunchedEffect(state.message) { kotlinx.coroutines.delay(2200); vm.clearMessage() }
        }
    }
}

@Composable
private fun RowScope.NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, null) }, label = { Text(label) })
}

@Composable
private fun HomeScreen(state: UiState, vm: KingFollowViewModel) {
    val sec = state.rewardSeconds.coerceAtLeast(0)
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الرصيد الحالي", style = MaterialTheme.typography.titleMedium)
                    Text("${state.user?.points ?: 0}", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.ExtraBold)
                    Text("نقطة")
                    Spacer(Modifier.height(18.dp))
                    LinearProgressIndicator(
                        progress = { 1f - (sec.coerceIn(0,3600) / 3600f) },
                        Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("المكافأة التالية خلال %02d:%02d:%02d".format(Locale.US, h, m, s), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = vm::claimReward, enabled = sec == 0) { Text("استلام 100 نقطة") }
                    Text("كل مكافأة يثبتها الخادم بعد مرور ساعة كاملة.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("الخدمات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { QuickPlatformCard("Facebook", "Followers / Likes") }
        item { QuickPlatformCard("X / Twitter", "Followers / Likes") }
    }
}

@Composable
private fun QuickPlatformCard(name: String, detail: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Public, null, Modifier.size(40.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold)
                Text(detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ServicesScreen(state: UiState, vm: KingFollowViewModel) {
    var platform by remember { mutableStateOf("facebook") }
    var url by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("100") }
    val followerService = state.services.filter { it.type == "followers" && it.enabled }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("طلب متابعين", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = platform == "facebook", onClick = { platform = "facebook" }, label = { Text("Facebook") })
                FilterChip(selected = platform == "x", onClick = { platform = "x" }, label = { Text("X / Twitter") })
            }
        }
        item { OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("رابط الحساب/الصفحة") }, singleLine = true) }
        item { OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit).take(7) }, Modifier.fillMaxWidth(), label = { Text("عدد المتابعين") }, singleLine = true) }
        item {
            val q = quantity.toIntOrNull()?.coerceAtLeast(0) ?: 0
            val rate = followerService.firstOrNull { it.platform == platform }?.cost_points ?: 0
            val blocks = if (q <= 0) 0 else ((q + 99) / 100)
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Text("التكلفة التقديرية: ${blocks * rate} نقطة", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.createFollowersOrder(platform, url, q) }, enabled = q > 0 && url.isNotBlank() && (state.user?.points ?: 0) >= blocks * rate, modifier = Modifier.fillMaxWidth()) {
                    Text("إنشاء طلب")
                }
            }}
        }
        item { Text("خدمات LikeStory-style المقابلة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(state.services) { s ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("${s.platform} • ${s.type}", fontWeight = FontWeight.Bold); Text("${s.cost_points} نقطة لكل ${s.unit}", style = MaterialTheme.typography.bodySmall) }
                    if (s.enabled) AssistChip(onClick = {}, label = { Text("متاح") })
                }
            }
        }
    }
}

@Composable
private fun OrdersScreen(orders: List<Order>, vm: KingFollowViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("طلباتي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        if (orders.isEmpty()) item { Text("لا توجد طلبات حتى الآن.") }
        items(orders, key = { it.id }) { o ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("#${o.id}", fontWeight = FontWeight.Bold)
                        Text(statusArabic(o.status), fontWeight = FontWeight.Bold)
                    }
                    Text("${o.platform} • ${o.service_type}")
                    Text("${o.delivered_count} / ${o.quantity}")
                    LinearProgressIndicator(progress = { if (o.quantity == 0) 0f else o.delivered_count.toFloat() / o.quantity.toFloat() }, Modifier.fillMaxWidth())
                    Text(o.target_url, style = MaterialTheme.typography.bodySmall)
                    if (o.status == "pending" || o.status == "processing") {
                        OutlinedButton(onClick = { vm.cancelOrder(o.id) }) { Text("إلغاء الطلب") }
                    }
                }
            }
        }
    }
}

private fun statusArabic(s: String): String = when (s) {
    "pending" -> "في الانتظار"
    "processing" -> "جارٍ التنفيذ"
    "partial" -> "تنفيذ جزئي"
    "completed" -> "مكتمل"
    "cancelled" -> "ملغى"
    "failed" -> "فشل"
    "refunded" -> "مسترد"
    else -> s
}

@Composable
private fun ProfileScreen(state: UiState, vm: KingFollowViewModel) {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حسابي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) {
            Text(state.user?.email ?: "", fontWeight = FontWeight.Bold)
            Text("الرصيد: ${state.user?.points ?: 0} نقطة")
        }}
        Text("الحسابات المرتبطة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        state.accounts.forEach { a ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, Modifier.size(36.dp)); Spacer(Modifier.width(12.dp)); Column {
                    Text(a.platform, fontWeight = FontWeight.Bold)
                    Text(a.username ?: a.display_name ?: "غير متصل", style = MaterialTheme.typography.bodySmall)
                }
            }}
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { uri.openUri("https://YOUR-DOMAIN.example/privacy") }, modifier = Modifier.fillMaxWidth()) { Text("الخصوصية") }
        OutlinedButton(onClick = vm::logout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
    }
}
